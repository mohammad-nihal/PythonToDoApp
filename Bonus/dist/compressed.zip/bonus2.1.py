password = input("Enter password: ")

while password != "Pass123":
    password = input("Enter password: ")


print("The password is correct!")
